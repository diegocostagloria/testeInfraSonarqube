package com.example.sonar;

import org.sonar.api.batch.fs.FileSystem;
import org.sonar.api.batch.sensor.Sensor;
import org.sonar.api.batch.sensor.SensorContext;
import org.sonar.api.batch.sensor.SensorDescriptor;
import org.sonar.api.utils.log.Logger;
import org.sonar.api.utils.log.Loggers;

import java.io.File;
import java.nio.file.Files;
import java.util.List;

public class CustomDependencySensor implements Sensor {

    private static final Logger LOG = Loggers.get(CustomDependencySensor.class);
    private static final String REQUIRED_DEPENDENCY = "com.example:example-dependency";

    @Override
    public void describe(SensorDescriptor descriptor) {
        descriptor.name("Custom Dependency Check Sensor");
    }

    @Override
    public void execute(SensorContext context) {
        FileSystem fs = context.fileSystem();
        fs.inputFiles(fs.predicates().hasLanguage("java")).forEach(inputFile -> {
            File file = inputFile.file();
            if (file.getName().equals("pom.xml")) {
                checkMavenDependency(file, context);
            } else if (file.getName().equals("build.gradle")) {
                checkGradleDependency(file, context);
            }
        });
    }

    private void checkMavenDependency(File file, SensorContext context) {
        try {
            List<String> lines = Files.readAllLines(file.toPath());
            boolean found = lines.stream().anyMatch(line -> line.contains(REQUIRED_DEPENDENCY));
            if (!found) {
                reportIssue(context, file, "Maven project is missing required dependency: " + REQUIRED_DEPENDENCY);
            }
        } catch (Exception e) {
            LOG.error("Error reading Maven file: " + file.getPath(), e);
        }
    }

    private void checkGradleDependency(File file, SensorContext context) {
        try {
            List<String> lines = Files.readAllLines(file.toPath());
            boolean found = lines.stream().anyMatch(line -> line.contains(REQUIRED_DEPENDENCY));
            if (!found) {
                reportIssue(context, file, "Gradle project is missing required dependency: " + REQUIRED_DEPENDENCY);
            }
        } catch (Exception e) {
            LOG.error("Error reading Gradle file: " + file.getPath(), e);
        }
    }

    private void reportIssue(SensorContext context, File file, String message) {
        // Implementação para reportar um problema no SonarQube
    }
}
