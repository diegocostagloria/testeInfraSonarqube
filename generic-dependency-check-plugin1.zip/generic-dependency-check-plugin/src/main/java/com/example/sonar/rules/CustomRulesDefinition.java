package com.example.sonar.rules;

import org.sonar.api.server.rule.RulesDefinition;

public class CustomRulesDefinition implements RulesDefinition {
    @Override
    public void define(Context context) {
        NewRepository repository = context.createRepository("custom-java-repo", "java").setName("Custom Java Repository");

        NewRule rule = repository.createRule("missing-dependency-check-rule")
                .setName("Missing Dependency Check")
                .setHtmlDescription("Checks if the required dependency is present in Maven and Gradle projects.");

        repository.done();
    }
}

