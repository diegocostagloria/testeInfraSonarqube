package com.example.sonar;

import org.sonar.api.Plugin;

public class CustomDependencyCheckPlugin implements Plugin {
    @Override
    public void define(Context context) {
        // Registrar as classes de verificações
        context.addExtension(CustomDependencySensor.class);
        //context.addExtension(com.example.sonar.rules.CustomRulesDefinition.class);
    }
}
