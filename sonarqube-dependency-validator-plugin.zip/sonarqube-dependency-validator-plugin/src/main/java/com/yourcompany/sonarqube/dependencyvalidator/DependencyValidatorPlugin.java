package com.yourcompany.sonarqube.dependencyvalidator;

import org.sonar.api.Plugin;

public class DependencyValidatorPlugin implements Plugin {
    @Override
    public void define(Context context) {
        context.addExtension(DependencyCheck.class);
        context.addExtension(Configuration.class);
    }
}
