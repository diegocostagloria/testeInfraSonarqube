package com.yourcompany.sonarqube.dependencyvalidator;

import org.sonar.api.config.PropertyDefinition;
import org.sonar.api.Plugin;

public class Configuration implements Plugin {
    @Override
    public void define(Context context) {
        context.addExtension(
            PropertyDefinition.builder("allowed.dependencies")
                .name("Allowed Dependencies")
                .description("List of allowed dependencies")
                .category("Dependency Validator")
                .build()
        );

        context.addExtension(
            PropertyDefinition.builder("prohibited.dependencies")
                .name("Prohibited Dependencies")
                .description("List of prohibited dependencies")
                .category("Dependency Validator")
                .build()
        );
    }
}
