package com.yourcompany.sonarqube.dependencyvalidator;

import org.sonar.api.batch.fs.FileSystem;
import org.sonar.api.batch.fs.InputFile;
import org.sonar.api.batch.sensor.Sensor;
import org.sonar.api.batch.sensor.SensorContext;
import org.sonar.api.batch.sensor.SensorDescriptor;
import org.sonar.api.batch.sensor.issue.NewIssue;
import org.sonar.api.batch.sensor.issue.NewIssueLocation;
import org.sonar.api.config.Configuration;
import org.sonar.api.rule.RuleKey;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DependencyCheck implements Sensor {

    private final Configuration configuration;
    private final FileSystem fileSystem;

    public DependencyCheck(Configuration configuration, FileSystem fileSystem) {
        this.configuration = configuration;
        this.fileSystem = fileSystem;
    }

    @Override
    public void describe(SensorDescriptor descriptor) {
        descriptor.name("Dependency Validator");
    }

    @Override
    public void execute(SensorContext context) {
        Iterable<InputFile> inputFiles = fileSystem.inputFiles(fileSystem.predicates().hasType(InputFile.Type.MAIN));

        Set<String> allowedDependencies = getConfiguredDependencies("allowed.dependencies");
        Set<String> prohibitedDependencies = getConfiguredDependencies("prohibited.dependencies");

        for (InputFile inputFile : inputFiles) {
            if (inputFile.filename().equals("pom.xml") || inputFile.filename().equals("build.gradle")) {
                validateDependencies(context, inputFile, allowedDependencies, prohibitedDependencies);
            }
        }
    }

    private Set<String> getConfiguredDependencies(String key) {
        String dependencies = configuration.get(key).orElse("");
        return Stream.of(dependencies.split(",")).collect(Collectors.toSet());
    }

    private void validateDependencies(SensorContext context, InputFile inputFile, Set<String> allowedDependencies, Set<String> prohibitedDependencies) {
        try {
            List<String> lines = Files.readAllLines(new File(inputFile.uri()).toPath());
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i).trim();
                for (String dependency : prohibitedDependencies) {
                    if (line.contains(dependency)) {
                        reportIssue(context, inputFile, i + 1, "Prohibited dependency found: " + dependency);
                    }
                }
                for (String dependency : allowedDependencies) {
                    if (!line.contains(dependency)) {
                        reportIssue(context, inputFile, i + 1, "Dependency not allowed: " + dependency);
                    }
                }
            }
        } catch (Exception e) {
            // Handle exceptions
        }
    }

    private void reportIssue(SensorContext context, InputFile inputFile, int lineNumber, String message) {
        RuleKey ruleKey = RuleKey.of("dependency-rules", "dependency-validation");
        NewIssue newIssue = context.newIssue().forRule(ruleKey);
        NewIssueLocation primaryLocation = newIssue.newLocation()
            .on(inputFile)
            .at(inputFile.selectLine(lineNumber))
            .message(message);
        newIssue.at(primaryLocation);
        newIssue.save();
    }
}
